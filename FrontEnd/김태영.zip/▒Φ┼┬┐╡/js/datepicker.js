$(function(){
  $('.input-group.date').datepicker({
      calendarWeeks: false,
      todayHighlight: true,
      autoclose: true,
      format: "yyyy/mm/dd",
      language: "kr"
  });
});
