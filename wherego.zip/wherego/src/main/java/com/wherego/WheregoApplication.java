package com.wherego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WheregoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WheregoApplication.class, args);
	}

}
